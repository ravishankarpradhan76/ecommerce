import 'package:flutter/material.dart';

class AppColors {
  static const Color mainColor = Colors.blue;
}