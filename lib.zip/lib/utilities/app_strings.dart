class AppStrings{
  static const String appName = "E-commerce";
  static const String signIn = "Sign In";
}