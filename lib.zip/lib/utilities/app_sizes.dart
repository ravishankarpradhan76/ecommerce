class AppSizes{
  static const double buttonHeight = 50.0;
  static const double pagePadding = 15.0;
  static const double widgetPadding = 15.0;

}